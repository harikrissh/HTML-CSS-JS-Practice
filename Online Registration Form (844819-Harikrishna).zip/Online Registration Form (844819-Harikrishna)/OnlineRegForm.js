function validateForm(){
	var name=document.RegForm.username.value;
	var pwd=document.RegForm.pwd.value;
	var addr=document.RegForm.addr.value;
	var cty=document.RegForm.cty.value;
	var lang= document.querySelector('input[name="lang[]"]:checked');
  
	if(name==null || name==""){
		alert("Name can't be empty");
		return false;
	}
	if(pwd.length<7 || pwd.length>8)	{
		alert("Password must have Minimum 7 characters and Maximum 8 characters");
		return false;
	}
	if(addr.length==0 || addr==null){
		alert("Address can't be empty");
		return false;
	}else if(addr.length>250){
		alert("Address can't exceed 250 characters");
		return false;
	}
	if(cty=="Select Country"){
		alert("Please Select a Country");
		return false;
	}
	if(!lang){
    	alert("Please Select atleast one Language");
    	return false;
    }
}
