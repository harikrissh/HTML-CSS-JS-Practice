function validateForm(){
var name=document.hotelForm.username.value;
var pwd=document.hotelForm.pwd.value;
var pwd2=document.hotelForm.pwd2.value;
var addr=document.hotelForm.addr.value;
var email=document.hotelForm.email.value;
var mob=document.hotelForm.mob.value;

if(email==null || email==""){
alert("Please enter Email Id");
return false;
}
if(name==null || name==""){
alert("Name can't be empty");
return false;
}
if(pwd.length<7 || pwd.length>8){
alert("Password must have Minimum 7 characters and Maximum 8 characters");
return false;
}
if(pwd!=pwd2){
alert("Passwords doesn't match!");
return false;
}
if(addr.length==0 || addr==null){
alert("Address can't be empty");
return false;
}else if(addr.length>250){
alert("Address can't exceed 250 characters");
return false;
}
if(mob==null || mob==""){
alert("Please enter Mobile Number");
return false;
}
alert("The Form is submitted successfully.");
return true;
}
function resetForm(){
alert("Entered information will be cleared. Are you sure?");
document.hotelForm.reset();
}