function validateForm(){
var name=document.RegForm.username.value;
var pwd=document.RegForm.pwd.value;
var qual=document.getElementById("qual");
var qualSelected = qual.options[qual.selectedIndex].value;
var email=document.RegForm.email.value;
var mob=document.RegForm.mobl.value;
var applytype=document.getElementById("applytype");
var applytypeSelected = applytype.options[applytype.selectedIndex].value;
var male=document.getElementById("Male").checked;
var female=document.getElementById("Female").checked;
var ques=document.getElementById("ques");
var quesSelected = ques.options[ques.selectedIndex].value;
var ans=document.RegForm.secans.value;
 
if(name==null || name==""){
alert("User Name can't be empty");
return false;
}
if(pwd.length<7 || pwd.length>8) {
alert("Password must have minimum 7 characters and maximum 8 characters");
return false;
}
if(qualSelected==0){
alert("Please select a Qualification");
return false;
}
if(email==null || email==""){
alert("Please enter Primary Email Id");
return false;
}
if(mob=="" || mob==null || mob.length==0){
alert("Please enter Mobile Number");
return false;
}
if(applytypeSelected==0){
alert("Please Select Applying For");
return false;
}
if (male==""&&female=="") {
    alert("Please Select Your Gender");
    return false;
}
if(quesSelected==0){
alert("Please Select a Security Question");
return false;
}
if(ans==null || ans==""){
alert(" Please enter the Security Answer for the selected Security Question");
return false;
}
}
function ResetForm(){
alert("Entered information will be cleared. Are you sure?");
document.RegForm.reset();
}